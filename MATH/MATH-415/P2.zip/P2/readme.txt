Instructions:

Open main.m and run.
function inscrCircle = area(x)
inscrCircle = (sqrt(x)/2)^2*pi
end
function area=areasquare(length)
area=length^2
end
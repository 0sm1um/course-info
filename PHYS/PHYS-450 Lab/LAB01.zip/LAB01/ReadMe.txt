This submission is being submitted to gauge the expectations
for the lab reports. I suspect I may have to include more figures
such as a circuit diagram for the methods section or something along
those lines.

I've included my MATLAB code which I used to reach all of my
numbers also.
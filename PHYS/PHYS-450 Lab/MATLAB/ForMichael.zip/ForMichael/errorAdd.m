function Sum = errorAdd(A,B)
Sum = [A(1)+B(1) sqrt(A(2)^2+B(2)^2)];
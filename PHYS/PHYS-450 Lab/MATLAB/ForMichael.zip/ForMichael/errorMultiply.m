function product = errorProduct(A,B)
product = [A(1)*B(1) A(1)*B(1)*sqrt((A(2)/A(1))^2+(B(2)/B(1))^2)];
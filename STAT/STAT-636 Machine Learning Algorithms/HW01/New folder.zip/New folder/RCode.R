setwd("C:/Users/echo4/Class/STAT/STAT-636 Machine Learning Algorithms/HW01")
load("crx.new.data")

setwd("C:/Users/echo4/Class/STAT/STAT-636 Machine Learning Algorithms/HW05")
mydata <- read.table("GeneData_first15BT.csv", sep=",", header=TRUE, row.names=1)
BTresponse <- character(length(mydata$BT))
BTresponse[grep("B", mydata$BT)] <- "B"
BTresponse[grep("T", mydata$BT)] <- "T"
BTresponse <- as.factor(BTresponse)
BTdata <- data.frame(BTresponse, mydata[,-16])

prp(BRdata)

library(rpart)
?rpart
?rpart.control

first100df <- data.frame(BTresponse, mydata[,1:15])
head(first100df)
myrpart <- rpart(BTresponse ~ ., data=first100df)
names(myrpart)
myrpart
# Draw a classification tree
plot(myrpart)
text(myrpart)

# install.packages("rpart.plot") # only do this once
library(rpart.plot)
# use "extra" option to add rates
prp(myrpart, extra=3)

myrpartPredict <- predict(myrpart, type="class")
myrpartPredict
table(myrpartPredict, BTresponse)




logis.fit <- glm(BTresponse ~ X1000_at  + X1001_at + X1002_f_at + X1003_s_at + X1004_at +
                   X1005_at + X1006_at + X1007_s_at + X1008_f_at + X1008_f_at + X1009_at +
                   X100_g_at + X1010_at + X1011_s_at + X1012_at + X1013_at,
                 data = BTdata, family = binomial)
summary(logis.fit)



# show importance of variables
myrpart$variable.importance
sum(myrpart$variable.importance)

# Prune an overgrown tree
myrpart.full <- rpart(BTresponse ~ ., data=first100df, 
                      control = rpart.control(minsplit = 2))
prp(myrpart.full, extra=1)
myrpart.pruned <- prune(myrpart.full, cp = 0.1)
prp(myrpart.pruned, extra=1)

# Regression tree
age <- mydata$age
summary(age)
myagedf <- data.frame(age, mydata[,1:15])
myagetree <- rpart(age ~ ., data=myagedf)
myagetree

# Draw the regression tree
plot(myagetree)
text(myagetree)
# A better way
prp(myagetree)

myagetree$variable.importance

# install.packages("randomForest") # Only once
library(randomForest)
?randomForest
myrf <- randomForest(BTresponse ~ ., data=first100df)
myrf
varImpPlot(myrf)


